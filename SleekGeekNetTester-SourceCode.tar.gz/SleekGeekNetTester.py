#!/usr/bin/env python3
import subprocess
import tkinter as tk
from tkinter import ttk, Menu
import webbrowser

class NetTesterApp:
    def __init__(self, root):
        root.title("SleekGeek.io Net Tester")
        root.geometry("1280x1024")  # Updated default size

        self.target_var = tk.StringVar()
        self.result_text = tk.Text(root, wrap='word', height=20, width=100)  # Adjusted height
        self.result_text.grid(row=1, column=1, sticky=tk.W, columnspan=4, padx=10)  # Adjusted columnspan

        # Vertical scrollbar
        scrollbar = ttk.Scrollbar(root, orient="vertical", command=self.result_text.yview)
        scrollbar.grid(row=1, column=5, sticky=(tk.N, tk.S))
        self.result_text["yscrollcommand"] = scrollbar.set

        # Target and Result
        ttk.Label(root, text="Target:").grid(row=0, column=0, sticky=tk.W)
        ttk.Entry(root, textvariable=self.target_var, width=30).grid(row=0, column=1, sticky=(tk.W, tk.E), padx=5)  # Adjusted width

        # Buttons
        ttk.Button(root, text="Initiate Ping Test", command=self.run_ping).grid(row=2, column=0, pady=10, padx=5, sticky=tk.W)
        ttk.Button(root, text="Initiate Traceroute", command=self.run_traceroute).grid(row=2, column=1, pady=10, padx=5, sticky=tk.W)
        ttk.Button(root, text="Perform NSLookUp", command=self.run_nslookup).grid(row=2, column=2, pady=10, padx=5, sticky=tk.W)
        ttk.Button(root, text="Whois Lookup", command=self.open_whois).grid(row=2, column=3, pady=10, padx=5, sticky=tk.W)  # Updated Whois Lookup button
        ttk.Button(root, text="Reset", command=self.reset_view).grid(row=3, column=0, pady=10, sticky=tk.W)

        # Help menu
        menubar = tk.Menu(root)
        root.config(menu=menubar)
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)

        # Right-click menu for the result text field
        result_menu = Menu(root, tearoff=0)
        result_menu.add_command(label="Copy", command=self.copy_result)
        self.result_text.bind("<Button-3>", lambda event: result_menu.post(event.x_root, event.y_root))

    def run_ping(self):
        target = self.target_var.get()

        if target:
            try:
                result = subprocess.check_output(['ping', '-c', '4', target], text=True)
                self.display_result(result)
            except subprocess.CalledProcessError as e:
                self.display_result("Error: {}".format(e))
        else:
            self.display_result("Please enter a target.")

    def run_traceroute(self):
        target = self.target_var.get()

        if target:
            try:
                result = subprocess.check_output(['traceroute', target], text=True)
                self.display_result(result)
            except subprocess.CalledProcessError as e:
                self.display_result("Error: {}".format(e))
        else:
            self.display_result("Please enter a target.")

    def run_nslookup(self):
        target = self.target_var.get()

        if target:
            try:
                result = subprocess.check_output(['nslookup', target], text=True)
                self.display_result(result)
            except subprocess.CalledProcessError as e:
                self.display_result("Error: {}".format(e))
        else:
            self.display_result("Please enter a target.")

    def open_whois(self):
        webbrowser.open_new("https://whois.domaintools.com/")

    def reset_view(self):
        self.target_var.set("")
        self.result_text.delete(1.0, tk.END)  # Clear the result text

    def show_about(self):
        about_text = (
            "SleekGeek.io Net Tester\n"
            "Version 1.0\n"
            "(C) 2023 by Anthony Kinyon"
        )

        about_window = tk.Toplevel()
        about_window.title("About")
        about_window.geometry("400x180")  # Adjusted height

        about_label = tk.Label(about_window, text=about_text, padx=10, pady=10, justify=tk.LEFT)
        about_label.grid(row=0, column=0)

    def display_result(self, result):
        current_results = self.result_text.get(1.0, tk.END)
        self.result_text.delete(1.0, tk.END)
        if current_results:
            self.result_text.insert(tk.END, current_results + "\n\n" + " " * 4 + result)
        else:
            self.result_text.insert(tk.END, " " * 4 + result)
        self.result_text.see(tk.END)  # Scroll to the bottom

    def copy_result(self):
        selected_text = self.result_text.selection_get() if self.result_text.tag_ranges(tk.SEL) else self.result_text.get(1.0, tk.END)
        self.result_text.clipboard_clear()
        self.result_text.clipboard_append(selected_text)

if __name__ == "__main__":
    root = tk.Tk()
    app = NetTesterApp(root)
    root.mainloop()
